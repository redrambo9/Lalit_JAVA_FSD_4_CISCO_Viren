import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.css']
})
// interface obj{
//   ID: string,
//   Brand:string,
//   Quantity:string,
//   Price:number
// }
export class SelectComponent implements OnInit {
  searchvalue="";
  arr:any[]=[];
  constructor(private eservice:ExampleService,private router:Router) {  }

  ngOnInit(): void {
   
    this.searchvalue=this.eservice.getsearchvalue();
     if(this.searchvalue.toLowerCase() === 'honey'){
      this.arr=[
    
        { ID :  'H01',
          Brand : 'Dabur',
          Quantity : '250g',
          Price : 250.0
    
        },
    
        { ID :  'H02',
          Brand : 'Saffola',
          Quantity : '500g',
          Price : 500.0
    
        }
    
    
       
      ];   
     }
     else if(this.searchvalue.toLowerCase() === 'eggs'){
       this.arr=[
        { ID :  'E01',
        Brand : 'Freshca',
        Quantity : '30Pcs',
        Price : 350.0
  
      },
  
      { ID :  'E02',
        Brand : 'KingFresh',
        Quantity : '10Pcs',
        Price : 90.0
  
      }
       ]
     }

     else if(this.searchvalue.toLowerCase() === 'milk'){
      this.arr=[
        { ID :  'M01',
        Brand : 'Amul',
        Quantity : '500ml',
        Price : 30.0
  
      },
  
      { ID :  'M02',
        Brand : 'Mother Dairy',
        Quantity : '1L',
        Price : 60.0
  
      }
      ]
    }

    else if(this.searchvalue.toLowerCase() === 'bread'){
      this.arr=[
        { ID :  'B01',
      Brand : 'Britania',
      Quantity : '400g',
      Price : 30.0

    },

    { ID :  'B02',
      Brand : 'Harvest',
      Quantity : '350g',
      Price : 60.0

    }
      ]
    }
  }
  
  // Honey=[
    
  //   { ID :  'H01',
  //     Brand : 'Dabur',
  //     Quantity : '250g',
  //     Price : 250.0

  //   },

  //   { ID :  'H02',
  //     Brand : 'Saffola',
  //     Quantity : '500g',
  //     Price : 500.0

  //   }


   
  // ]

  // Eggs=[
    
  //   { ID :  'E01',
  //     Brand : 'Freshca',
  //     Quantity : '30Pcs',
  //     Price : 350.0

  //   },

  //   { ID :  'E02',
  //     Brand : 'KingFresh',
  //     Quantity : '10Pcs',
  //     Price : 90.0

  //   }


   
  // ]
  cartItems:any=[];
  
  onContinue(){
     if(this.cartItems.length===0){
       alert("Select products to continue.");
       return;
     }
     this.eservice.index=this.cartItems;
     this.router.navigate(['/cart']);
  }

  onCheck(event:any,i: any){
    if(event.target.checked){
     
      this.cartItems.push(i);
    }
    else {
      if(this.cartItems.indexof(i)!==-1){
          this.cartItems.splice(this.cartItems.indexof(i),1);
      }
    }
  }

}

