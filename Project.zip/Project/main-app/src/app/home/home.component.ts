import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  searchString="";

  product=["honey","eggs","milk","bread"];

  constructor(private exampleservice:ExampleService,private router:Router) { }

  ngOnInit(): void {
    
    
    
  }
  onclick2(){
    alert("Search Your Product in the Search bar!!");
  }

  

  onclick(){
    
    let index=-1;
    let flag =0;
     for(let i = 0 ; i < this.product.length ; i++){
          
        if(this.searchString.toLowerCase() === this.product[i]){
            index=i;
            flag=1;
            break;
        }
        
     }
     if(flag===1){
        this.exampleservice.setsearchvalue(this.product[index]);
        this.router.navigate(['/select']);
     }
     else{
       alert(" Sorry😞!! This Product is Not Available at the moment!!.");
     }
    
  }

  

}
