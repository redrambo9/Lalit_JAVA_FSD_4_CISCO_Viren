import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ExampleService {
  
   searchvalue="";
  constructor() { }
  index:any=[];
  sum=0;
  Honey=[
    
    { ID :  'H01',
      Brand : 'Dabur',
      Quantity : '250g',
      Price : 250.0

    },

    { ID :  'H02',
      Brand : 'Saffola',
      Quantity : '500g',
      Price : 500.0

    }


   
  ]

  Eggs=[
    
    { ID :  'E01',
      Brand : 'Freshca',
      Quantity : '30Pcs',
      Price : 350.0

    },

    { ID :  'E02',
      Brand : 'KingFresh',
      Quantity : '10Pcs',
      Price : 90.0

    }
  ]

  Milk=[
    
    { ID :  'M01',
      Brand : 'Amul',
      Quantity : '500ml',
      Price : 30.0

    },

    { ID :  'M02',
      Brand : 'Mother Dairy',
      Quantity : '1L',
      Price : 60.0

    }
  ]

  
  Bread=[
    
    { ID :  'B01',
      Brand : 'Britania',
      Quantity : '400g',
      Price : 30.0

    },

    { ID :  'B02',
      Brand : 'Harvest',
      Quantity : '350g',
      Price : 60.0

    }
  ]


  getsearchvalue(){

    return this.searchvalue;
  }
  setsearchvalue(searchparam:string){
    
    this.searchvalue=searchparam;
  }
}

